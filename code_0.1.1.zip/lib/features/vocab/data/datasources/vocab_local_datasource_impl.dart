import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:isar_community/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'vocab_local_datasource.dart';
import '../models/vocab_isar_model.dart';
import '../models/character_isar_model.dart';

// ============================================================================
// Pinyin Normalisation
// "nǐ hǎo" → "nihao"  |  "ni3hao3" → "nihao"
// ============================================================================
String normalizePinyin(String pinyin) {
  const toneMap = {
    'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
    'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
    'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
    'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
    'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
    'ǖ': 'v', 'ǘ': 'v', 'ǚ': 'v', 'ǜ': 'v', 'ü': 'v',
  };
  var result = pinyin.toLowerCase();
  toneMap.forEach((toned, plain) => result = result.replaceAll(toned, plain));
  // xoá khoảng trắng và số thanh điệu
  return result.replaceAll(RegExp(r'[\s\d]'), '');
}

// ============================================================================
// VocabLocalDataSourceImpl
// ============================================================================
class VocabLocalDataSourceImpl implements VocabLocalDataSource {
  final Isar isar;
  VocabLocalDataSourceImpl(this.isar);

  // ── Basic CRUD ─────────────────────────────────────────────────────────────

  @override
  Future<List<VocabIsarModel>> getAll() async {
    return isar.vocabIsarModels
        .where()
        .sortByLevel()
        .thenByHanzi()
        .findAll();
  }

  @override
  Future<List<VocabIsarModel>> getDue() async {
    final now = DateTime.now().toUtc();
    return isar.vocabIsarModels
        .filter()
        .nextReviewLessThan(now)
        .findAll();
  }

  @override
  Future<List<VocabIsarModel>> getByLevel(int level) async {
    return isar.vocabIsarModels
        .filter()
        .levelEqualTo(level)
        .sortByHanzi()
        .findAll();
  }

  @override
  Future<void> update(VocabIsarModel model) async {
    await isar.writeTxn(() async {
      final existing = await isar.vocabIsarModels
          .filter()
          .idEqualTo(model.id)
          .findFirst();
      if (existing != null) model.isarId = existing.isarId;
      await isar.vocabIsarModels.put(model);
    });
  }

  @override
  Future<void> insert(VocabIsarModel model) async {
    await isar.writeTxn(() async {
      final existing = await isar.vocabIsarModels
          .filter()
          .idEqualTo(model.id)
          .findFirst();
      if (existing != null) model.isarId = existing.isarId;
      await isar.vocabIsarModels.put(model);
    });
  }

  // ── Search ─────────────────────────────────────────────────────────────────

  @override
  Future<List<VocabIsarModel>> search(
    String query, {
    int? hskLevel,
    String? wordType,
  }) async {
    if (query.trim().isEmpty) {
      // Không có query → trả toàn bộ (hoặc filter theo level/type)
      var q = isar.vocabIsarModels.where().sortByLevel().thenByHanzi();
      var results = await q.findAll();
      return _applyFilters(results, hskLevel, wordType);
    }

    final normalizedQuery = normalizePinyin(query.trim());

    // Dùng Isar native query trên các @Index fields:
    // 1. hanzi starts-with (ví dụ: "你好" starts với "你")
    // 2. pinyinNormalized starts-with (ví dụ: "nihao" starts với "ni")
    // 3. hanzi contains (cho search ở giữa)
    final byHanziStart = await isar.vocabIsarModels
        .filter()
        .hanziStartsWith(query.trim())
        .sortByLevel()
        .thenByHanzi()
        .findAll();

    final byPinyinStart = await isar.vocabIsarModels
        .filter()
        .pinyinNormalizedStartsWith(normalizedQuery, caseSensitive: false)
        .sortByLevel()
        .thenByHanzi()
        .findAll();

    // Fallback: contains search cho meaning (chạy trên tất cả, filter trong Dart)
    final allModels = await isar.vocabIsarModels
        .where()
        .sortByLevel()
        .thenByHanzi()
        .findAll();

    final q = query.trim().toLowerCase();
    final byMeaning = allModels.where((v) {
      // tìm trong flat meaning string và trong meanings list
      return v.meaning.toLowerCase().contains(q) ||
          v.meanings.any((m) => m.vi.toLowerCase().contains(q));
    }).toList();

    // Merge, dedup theo id, giữ thứ tự: hanzi → pinyin → meaning
    final seen = <String>{};
    final merged = <VocabIsarModel>[];
    for (final list in [byHanziStart, byPinyinStart, byMeaning]) {
      for (final item in list) {
        if (seen.add(item.id)) merged.add(item);
      }
    }

    return _applyFilters(merged, hskLevel, wordType);
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  List<VocabIsarModel> _applyFilters(
    List<VocabIsarModel> list,
    int? hskLevel,
    String? wordType,
  ) {
    var result = list;
    if (hskLevel != null && hskLevel > 0) {
      result = result.where((v) => v.level == hskLevel).toList();
    }
    if (wordType != null && wordType != 'all') {
      result = result.where((v) {
        // kiểm tra wordType field hoặc meanings list
        return v.wordType == wordType ||
            v.meanings.any((m) => m.pos == wordType);
      }).toList();
    }
    return result;
  }

  // ── DB Init ────────────────────────────────────────────────────────────────

  static Future<Isar> initDB() async {
    final dir = await getApplicationDocumentsDirectory();
    final isar = await Isar.open(
      [VocabIsarModelSchema, CharacterIsarModelSchema],
      directory: dir.path,
    );

    if (await isar.vocabIsarModels.count() == 0) {
      await _seedVocabData(isar);
    }
    if (await isar.characterIsarModels.count() == 0) {
      await _seedCharacterData(isar);
    }

    return isar;
  }

  // ── Seed Vocab ─────────────────────────────────────────────────────────────

  static Future<void> _seedVocabData(Isar isar) async {
    try {
      // Thử load vocab_base.json (format mới, List)
      final jsonStr =
          await rootBundle.loadString('assets/data/vocab_base.json');
      final decoded = json.decode(jsonStr);

      List<VocabIsarModel> models;

      if (decoded is List) {
        // Format mới: [{...}, {...}]
        models = decoded
            .map((v) => VocabIsarModel.fromJson(v as Map<String, dynamic>))
            .toList();
      } else if (decoded is Map) {
        // Format cũ: {"hsk1_001": {...}}  — backwards compat
        models = (decoded as Map<String, dynamic>)
            .entries
            .map((e) {
              final v = e.value as Map<String, dynamic>;
              v['id'] = e.key; // inject id từ key
              return VocabIsarModel.fromJson(v);
            })
            .toList();
      } else {
        models = [];
      }

      // Optional: load HSK 5-6
      try {
        final ext =
            await rootBundle.loadString('assets/data/vocab_hsk56.json');
        final extDecoded = json.decode(ext) as List;
        models.addAll(extDecoded
            .map((v) => VocabIsarModel.fromJson(v as Map<String, dynamic>))
            .toList());
      } catch (_) {
        // File chưa có → bỏ qua
      }

      await isar.writeTxn(
          () async => await isar.vocabIsarModels.putAll(models));
      // ignore: avoid_print
      print('✅ Seeded ${models.length} vocab items');
    } catch (e) {
      // ignore: avoid_print
      print('❌ Vocab seed error: $e');
    }
  }

  // ── Seed Characters ────────────────────────────────────────────────────────

  static Future<void> _seedCharacterData(Isar isar) async {
    try {
      final jsonStr =
          await rootBundle.loadString('assets/data/char_base.json');
      final List<dynamic> charList = json.decode(jsonStr);
      final models = charList
          .map((c) => CharacterIsarModel.fromJson(c as Map<String, dynamic>))
          .toList();

      // Optional: load HSK 5-6 characters
      try {
        final ext =
            await rootBundle.loadString('assets/data/char_hsk56.json');
        final extList = json.decode(ext) as List;
        models.addAll(extList
            .map((c) =>
                CharacterIsarModel.fromJson(c as Map<String, dynamic>))
            .toList());
      } catch (_) {
        // File chưa có → bỏ qua
      }

      await isar.writeTxn(
          () async => await isar.characterIsarModels.putAll(models));
      // ignore: avoid_print
      print('✅ Seeded ${models.length} character items');
    } catch (e) {
      // ignore: avoid_print
      print('❌ Character seed error: $e');
    }
  }
}
