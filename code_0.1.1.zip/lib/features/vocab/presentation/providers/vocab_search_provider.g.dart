// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vocab_search_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(searchVocab)
final searchVocabProvider = SearchVocabFamily._();

final class SearchVocabProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<Vocab>>,
          List<Vocab>,
          FutureOr<List<Vocab>>
        >
    with $FutureModifier<List<Vocab>>, $FutureProvider<List<Vocab>> {
  SearchVocabProvider._({
    required SearchVocabFamily super.from,
    required (String, {int? hskLevel, String? wordType}) super.argument,
  }) : super(
         retry: null,
         name: r'searchVocabProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$searchVocabHash();

  @override
  String toString() {
    return r'searchVocabProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  $FutureProviderElement<List<Vocab>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<Vocab>> create(Ref ref) {
    final argument =
        this.argument as (String, {int? hskLevel, String? wordType});
    return searchVocab(
      ref,
      argument.$1,
      hskLevel: argument.hskLevel,
      wordType: argument.wordType,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is SearchVocabProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$searchVocabHash() => r'e656226b701da5f27b2654d7bf383f581c4c89eb';

final class SearchVocabFamily extends $Family
    with
        $FunctionalFamilyOverride<
          FutureOr<List<Vocab>>,
          (String, {int? hskLevel, String? wordType})
        > {
  SearchVocabFamily._()
    : super(
        retry: null,
        name: r'searchVocabProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  SearchVocabProvider call(String query, {int? hskLevel, String? wordType}) =>
      SearchVocabProvider._(
        argument: (query, hskLevel: hskLevel, wordType: wordType),
        from: this,
      );

  @override
  String toString() => r'searchVocabProvider';
}

@ProviderFor(vocabByLevel)
final vocabByLevelProvider = VocabByLevelFamily._();

final class VocabByLevelProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<Vocab>>,
          List<Vocab>,
          FutureOr<List<Vocab>>
        >
    with $FutureModifier<List<Vocab>>, $FutureProvider<List<Vocab>> {
  VocabByLevelProvider._({
    required VocabByLevelFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'vocabByLevelProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$vocabByLevelHash();

  @override
  String toString() {
    return r'vocabByLevelProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<List<Vocab>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<Vocab>> create(Ref ref) {
    final argument = this.argument as int;
    return vocabByLevel(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is VocabByLevelProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$vocabByLevelHash() => r'13030ddd84d32c9f69b9ca220225cab151e2c410';

final class VocabByLevelFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<List<Vocab>>, int> {
  VocabByLevelFamily._()
    : super(
        retry: null,
        name: r'vocabByLevelProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  VocabByLevelProvider call(int level) =>
      VocabByLevelProvider._(argument: level, from: this);

  @override
  String toString() => r'vocabByLevelProvider';
}
