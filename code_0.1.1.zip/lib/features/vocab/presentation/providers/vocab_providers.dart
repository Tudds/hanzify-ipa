import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:isar_community/isar.dart';
import '../../data/datasources/vocab_local_datasource.dart';
import '../../data/datasources/vocab_local_datasource_impl.dart';
import '../../data/repositories/vocab_repository_impl.dart';
import '../../domain/repositories/vocab_repository.dart';

part 'vocab_providers.g.dart';

@Riverpod(keepAlive: true)
Isar isarDb(Ref ref) {
  // Overridden in main.dart
  throw UnimplementedError();
}

@Riverpod(keepAlive: true)
VocabLocalDataSource vocabLocalDataSource(Ref ref) {
  final isar = ref.watch(isarDbProvider);
  return VocabLocalDataSourceImpl(isar);
}

@Riverpod(keepAlive: true)
VocabRepository vocabRepository(Ref ref) {
  final localDataSource = ref.watch(vocabLocalDataSourceProvider);
  return VocabRepositoryImpl(localDataSource);
}
