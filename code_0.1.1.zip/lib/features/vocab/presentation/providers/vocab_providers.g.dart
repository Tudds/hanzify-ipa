// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vocab_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(isarDb)
final isarDbProvider = IsarDbProvider._();

final class IsarDbProvider extends $FunctionalProvider<Isar, Isar, Isar>
    with $Provider<Isar> {
  IsarDbProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'isarDbProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$isarDbHash();

  @$internal
  @override
  $ProviderElement<Isar> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Isar create(Ref ref) {
    return isarDb(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Isar value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Isar>(value),
    );
  }
}

String _$isarDbHash() => r'591fb13ca250237af88b8ad2c5311ef119e51813';

@ProviderFor(vocabLocalDataSource)
final vocabLocalDataSourceProvider = VocabLocalDataSourceProvider._();

final class VocabLocalDataSourceProvider
    extends
        $FunctionalProvider<
          VocabLocalDataSource,
          VocabLocalDataSource,
          VocabLocalDataSource
        >
    with $Provider<VocabLocalDataSource> {
  VocabLocalDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'vocabLocalDataSourceProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$vocabLocalDataSourceHash();

  @$internal
  @override
  $ProviderElement<VocabLocalDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  VocabLocalDataSource create(Ref ref) {
    return vocabLocalDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(VocabLocalDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<VocabLocalDataSource>(value),
    );
  }
}

String _$vocabLocalDataSourceHash() =>
    r'f56a46a46b15b19289cf3651874a673bd1ee6dfb';

@ProviderFor(vocabRepository)
final vocabRepositoryProvider = VocabRepositoryProvider._();

final class VocabRepositoryProvider
    extends
        $FunctionalProvider<VocabRepository, VocabRepository, VocabRepository>
    with $Provider<VocabRepository> {
  VocabRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'vocabRepositoryProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$vocabRepositoryHash();

  @$internal
  @override
  $ProviderElement<VocabRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  VocabRepository create(Ref ref) {
    return vocabRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(VocabRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<VocabRepository>(value),
    );
  }
}

String _$vocabRepositoryHash() => r'9516de3be452e6db691b18a5943aad5a989d2888';
