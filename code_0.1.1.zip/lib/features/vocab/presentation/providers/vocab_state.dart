import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/vocab.dart';
import '../../domain/usecases/review_vocab.dart';
import 'vocab_providers.dart';

part 'vocab_state.g.dart';

// ============================================================================
// DueVocabNotifier — danh sách từ cần ôn hôm nay
// ============================================================================
@Riverpod(keepAlive: true)
class DueVocabNotifier extends _$DueVocabNotifier {
  @override
  Future<List<Vocab>> build() async {
    final repository = ref.watch(vocabRepositoryProvider);
    return repository.getDue();
  }

  Future<void> review(Vocab vocab, int quality) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      final repository = ref.read(vocabRepositoryProvider);
      final updatedVocab = ReviewVocab()(vocab, quality);
      await repository.update(updatedVocab);
      ref.invalidate(allVocabProvider);
      return repository.getDue();
    });
  }
}

// ============================================================================
// AllVocabNotifier — toàn bộ vocab, hỗ trợ search + invalidate
// ============================================================================
@Riverpod(keepAlive: true)
class AllVocabNotifier extends _$AllVocabNotifier {
  @override
  Future<List<Vocab>> build() async {
    final repository = ref.watch(vocabRepositoryProvider);
    return repository.getAll();
  }

  /// Search full-text: hanzi, pinyin, pinyin không dấu, nghĩa tiếng Việt
  Future<void> search(String query, {int? hskLevel, String? wordType}) async {
    if (query.isEmpty && hskLevel == null && wordType == null) {
      ref.invalidateSelf();
      return;
    }
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      return ref.read(vocabRepositoryProvider).search(
            query,
            hskLevel: hskLevel,
            wordType: wordType,
          );
    });
  }

  /// Bookmark toggle
  Future<void> toggleBookmark(Vocab vocab) async {
    state = await AsyncValue.guard(() async {
      final updated = vocab.copyWith(isBookmarked: !vocab.isBookmarked);
      await ref.read(vocabRepositoryProvider).update(updated);
      return ref.read(vocabRepositoryProvider).getAll();
    });
  }

  /// Mark mastered toggle
  Future<void> toggleMastered(Vocab vocab) async {
    state = await AsyncValue.guard(() async {
      final updated = vocab.copyWith(isMastered: !vocab.isMastered);
      await ref.read(vocabRepositoryProvider).update(updated);
      return ref.read(vocabRepositoryProvider).getAll();
    });
  }
}
