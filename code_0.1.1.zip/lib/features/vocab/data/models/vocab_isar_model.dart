// ignore_for_file: experimental_member_use
import 'package:isar_community/isar.dart';
import '../../domain/entities/vocab.dart';

part 'vocab_isar_model.g.dart';

// ============================================================================
// Embedded: MeaningEmbedded
// ============================================================================
@embedded
class MeaningEmbedded {
  /// Từ loại: "v" | "n" | "adj" | "adv" | "prep" | "conj" |
  ///          "pron" | "num" | "mw" | "aux" | "interj" | "other"
  late String pos;

  /// Nghĩa tiếng Việt
  late String vi;

  /// Nghĩa tiếng Anh (tuỳ chọn, cho tương lai)
  String? en;

  MeaningEmbedded();

  MeaningEmbedded.from({required this.pos, required this.vi, this.en});
}

// ============================================================================
// Embedded: ExampleSentenceEmbedded
// ============================================================================
@embedded
class ExampleSentenceEmbedded {
  /// Câu tiếng Trung
  late String cn;

  /// Pinyin có dấu
  late String pinyin;

  /// Dịch tiếng Việt
  late String vi;

  ExampleSentenceEmbedded();

  ExampleSentenceEmbedded.from({
    required this.cn,
    required this.pinyin,
    required this.vi,
  });
}

// ============================================================================
// Collection: VocabIsarModel
// ============================================================================
@collection
class VocabIsarModel {
  Id isarId = Isar.autoIncrement;

  @Index(unique: true, replace: true)
  late String id;

  @Index(type: IndexType.value)
  late String hanzi;

  late String pinyin;

  /// Pinyin không dấu, không khoảng trắng: "nǐ hǎo" → "nihao"
  @Index(type: IndexType.value)
  late String pinyinNormalized;

  /// Các chữ riêng lẻ tạo thành từ: ["你", "好"]
  late List<String> characters;

  /// Danh sách nghĩa + từ loại
  late List<MeaningEmbedded> meanings;

  /// Chuỗi nghĩa phẳng (dùng cho hiển thị nhanh & tìm kiếm fallback)
  late String meaning;

  /// Câu ví dụ có cấu trúc
  late List<ExampleSentenceEmbedded> exampleSentences;

  @Index()
  late int level;

  @Index()
  late String wordType;

  late bool isBookmarked;
  late bool isMastered;

  // SRS fields
  late int repetitions;
  late double easeFactor;
  late int interval;

  @Index()
  late DateTime nextReview;

  @Index()
  late bool needsSync;

  late DateTime updatedAt;

  // ── fromEntity ─────────────────────────────────────────────────────────────

  static VocabIsarModel fromEntity(Vocab entity, {bool needsSync = true}) {
    return VocabIsarModel()
      ..id = entity.id
      ..hanzi = entity.hanzi
      ..pinyin = entity.pinyin
      ..pinyinNormalized = entity.pinyinNormalized
      ..characters = List<String>.from(entity.characters)
      ..meanings = entity.meanings
          .map((m) => MeaningEmbedded.from(pos: m.pos, vi: m.vi, en: m.en))
          .toList()
      ..meaning = entity.meaning
      ..exampleSentences = entity.exampleSentences
          .map((e) => ExampleSentenceEmbedded.from(
              cn: e.cn, pinyin: e.pinyin, vi: e.vi))
          .toList()
      ..level = entity.level
      ..wordType = entity.wordType
      ..isBookmarked = entity.isBookmarked
      ..isMastered = entity.isMastered
      ..repetitions = entity.repetitions
      ..easeFactor = entity.easeFactor
      ..interval = entity.interval
      ..nextReview = entity.nextReview.toUtc()
      ..needsSync = needsSync
      ..updatedAt = DateTime.now().toUtc();
  }

  // ── toEntity ───────────────────────────────────────────────────────────────

  Vocab toEntity() {
    return Vocab(
      id: id,
      hanzi: hanzi,
      pinyin: pinyin,
      pinyinNormalized: pinyinNormalized,
      characters: List<String>.from(characters),
      meanings: meanings
          .map((m) => Meaning(pos: m.pos, vi: m.vi, en: m.en ?? ''))
          .toList(),
      meaning: meaning,
      exampleSentences: exampleSentences
          .map((e) => ExampleSentence(cn: e.cn, pinyin: e.pinyin, vi: e.vi))
          .toList(),
      level: level,
      wordType: wordType,
      isBookmarked: isBookmarked,
      isMastered: isMastered,
      repetitions: repetitions,
      easeFactor: easeFactor,
      interval: interval,
      nextReview: nextReview.toLocal(),
    );
  }

  // ── fromJson (dùng khi seed từ assets) ────────────────────────────────────

  static VocabIsarModel fromJson(Map<String, dynamic> json) {
    // ── meanings ──────────────────────────────────────────────────────────
    List<MeaningEmbedded> meanings = [];
    if (json['meanings'] != null) {
      meanings = (json['meanings'] as List).map((m) {
        final map = m as Map<String, dynamic>;
        return MeaningEmbedded.from(
          pos: map['pos'] as String? ?? 'other',
          vi: map['vi'] as String? ?? '',
          en: map['en'] as String?,
        );
      }).toList();
    }

    // Flat meaning: dùng field 'meaning' hoặc derive từ meanings list
    final String flatMeaning = json['meaning'] as String? ??
        meanings.map((m) => '${m.pos}. ${m.vi}').join('; ');

    // ── exampleSentences ─────────────────────────────────────────────────
    List<ExampleSentenceEmbedded> examples = [];
    if (json['exampleSentences'] != null) {
      final raw = json['exampleSentences'] as List;
      if (raw.isNotEmpty && raw.first is Map) {
        // Format mới: [{cn, pinyin, vi}]
        examples = raw.map((e) {
          final map = e as Map<String, dynamic>;
          return ExampleSentenceEmbedded.from(
            cn: map['cn'] as String? ?? '',
            pinyin: map['pinyin'] as String? ?? '',
            vi: map['vi'] as String? ?? '',
          );
        }).toList();
      } else {
        // Format cũ: ["câu ví dụ"]
        examples = raw.map((s) => ExampleSentenceEmbedded.from(
            cn: s as String, pinyin: '', vi: '')).toList();
      }
    }

    // ── characters ───────────────────────────────────────────────────────
    List<String> characters = [];
    if (json['characters'] != null) {
      characters = List<String>.from(json['characters'] as List);
    } else {
      // Auto-derive từ hanzi string
      characters = (json['hanzi'] as String? ?? '').split('').toList();
    }

    // ── pinyin normalized ─────────────────────────────────────────────────
    final pinyin = json['pinyin'] as String? ?? '';
    final pinyinNorm = json['pinyinNormalized'] as String? ??
        _normalizePinyinLocal(pinyin);

    // ── wordType ─────────────────────────────────────────────────────────
    final wordType = json['wordType'] as String? ??
        (meanings.isNotEmpty ? meanings.first.pos : 'other');

    return VocabIsarModel()
      ..id = json['id'] as String? ??
          '${json['hanzi']}_${json['level']}'   // fallback id
      ..hanzi = json['hanzi'] as String? ?? ''
      ..pinyin = pinyin
      ..pinyinNormalized = pinyinNorm
      ..characters = characters
      ..meanings = meanings
      ..meaning = flatMeaning
      ..exampleSentences = examples
      ..level = json['level'] as int? ?? 1
      ..wordType = wordType
      ..isBookmarked = json['isBookmarked'] as bool? ?? false
      ..isMastered = json['isMastered'] as bool? ?? false
      ..repetitions = json['repetitions'] as int? ?? 0
      ..easeFactor = (json['easeFactor'] as num?)?.toDouble() ?? 2.5
      ..interval =
          json['interval'] as int? ?? json['srsInterval'] as int? ?? 0
      ..nextReview = DateTime.parse(
          json['nextReview'] as String? ??
              DateTime.now().toUtc().toIso8601String())
      ..needsSync = json['needsSync'] as bool? ?? false
      ..updatedAt = DateTime.now().toUtc();
  }

  // ── toJson ────────────────────────────────────────────────────────────────

  Map<String, dynamic> toJson() => {
    'id': id,
    'hanzi': hanzi,
    'pinyin': pinyin,
    'pinyinNormalized': pinyinNormalized,
    'characters': characters,
    'meanings': meanings.map((m) => {'pos': m.pos, 'vi': m.vi, 'en': m.en}).toList(),
    'meaning': meaning,
    'exampleSentences': exampleSentences
        .map((e) => {'cn': e.cn, 'pinyin': e.pinyin, 'vi': e.vi})
        .toList(),
    'level': level,
    'wordType': wordType,
    'isBookmarked': isBookmarked,
    'isMastered': isMastered,
    'repetitions': repetitions,
    'easeFactor': easeFactor,
    'interval': interval,
    'nextReview': nextReview.toUtc().toIso8601String(),
    'needsSync': needsSync,
  };

  // ── private helper ────────────────────────────────────────────────────────

  static String _normalizePinyinLocal(String pinyin) {
    const toneMap = {
      'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
      'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
      'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
      'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
      'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
      'ǖ': 'v', 'ǘ': 'v', 'ǚ': 'v', 'ǜ': 'v', 'ü': 'v',
    };
    var result = pinyin.toLowerCase();
    toneMap.forEach((t, p) => result = result.replaceAll(t, p));
    return result.replaceAll(RegExp(r'[\s\d]'), '');
  }
}
