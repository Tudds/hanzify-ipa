// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'character_isar_model.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetCharacterIsarModelCollection on Isar {
  IsarCollection<CharacterIsarModel> get characterIsarModels =>
      this.collection();
}

const CharacterIsarModelSchema = CollectionSchema(
  name: r'CharacterIsarModel',
  id: -2033106584088611085,
  properties: {
    r'char': PropertySchema(id: 0, name: r'char', type: IsarType.string),
    r'definition': PropertySchema(
      id: 1,
      name: r'definition',
      type: IsarType.string,
    ),
    r'definitionVi': PropertySchema(
      id: 2,
      name: r'definitionVi',
      type: IsarType.string,
    ),
    r'hskLevel': PropertySchema(id: 3, name: r'hskLevel', type: IsarType.long),
    r'pinyin': PropertySchema(id: 4, name: r'pinyin', type: IsarType.string),
    r'pinyinNormalized': PropertySchema(
      id: 5,
      name: r'pinyinNormalized',
      type: IsarType.string,
    ),
    r'radical': PropertySchema(id: 6, name: r'radical', type: IsarType.string),
    r'strokeCount': PropertySchema(
      id: 7,
      name: r'strokeCount',
      type: IsarType.long,
    ),
    r'strokes': PropertySchema(
      id: 8,
      name: r'strokes',
      type: IsarType.stringList,
    ),
    r'updatedAt': PropertySchema(
      id: 9,
      name: r'updatedAt',
      type: IsarType.dateTime,
    ),
  },

  estimateSize: _characterIsarModelEstimateSize,
  serialize: _characterIsarModelSerialize,
  deserialize: _characterIsarModelDeserialize,
  deserializeProp: _characterIsarModelDeserializeProp,
  idName: r'isarId',
  indexes: {
    r'char': IndexSchema(
      id: -4619403368090939982,
      name: r'char',
      unique: true,
      replace: true,
      properties: [
        IndexPropertySchema(
          name: r'char',
          type: IndexType.hash,
          caseSensitive: true,
        ),
      ],
    ),
    r'pinyinNormalized': IndexSchema(
      id: -5792813043327382502,
      name: r'pinyinNormalized',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'pinyinNormalized',
          type: IndexType.hash,
          caseSensitive: true,
        ),
      ],
    ),
    r'updatedAt': IndexSchema(
      id: -6238191080293565125,
      name: r'updatedAt',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'updatedAt',
          type: IndexType.value,
          caseSensitive: false,
        ),
      ],
    ),
  },
  links: {},
  embeddedSchemas: {},

  getId: _characterIsarModelGetId,
  getLinks: _characterIsarModelGetLinks,
  attach: _characterIsarModelAttach,
  version: '3.3.2',
);

int _characterIsarModelEstimateSize(
  CharacterIsarModel object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.char.length * 3;
  {
    final value = object.definition;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.definitionVi;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.pinyin;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.pinyinNormalized;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.radical;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  bytesCount += 3 + object.strokes.length * 3;
  {
    for (var i = 0; i < object.strokes.length; i++) {
      final value = object.strokes[i];
      bytesCount += value.length * 3;
    }
  }
  return bytesCount;
}

void _characterIsarModelSerialize(
  CharacterIsarModel object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeString(offsets[0], object.char);
  writer.writeString(offsets[1], object.definition);
  writer.writeString(offsets[2], object.definitionVi);
  writer.writeLong(offsets[3], object.hskLevel);
  writer.writeString(offsets[4], object.pinyin);
  writer.writeString(offsets[5], object.pinyinNormalized);
  writer.writeString(offsets[6], object.radical);
  writer.writeLong(offsets[7], object.strokeCount);
  writer.writeStringList(offsets[8], object.strokes);
  writer.writeDateTime(offsets[9], object.updatedAt);
}

CharacterIsarModel _characterIsarModelDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = CharacterIsarModel();
  object.char = reader.readString(offsets[0]);
  object.definition = reader.readStringOrNull(offsets[1]);
  object.definitionVi = reader.readStringOrNull(offsets[2]);
  object.hskLevel = reader.readLongOrNull(offsets[3]);
  object.isarId = id;
  object.pinyin = reader.readStringOrNull(offsets[4]);
  object.pinyinNormalized = reader.readStringOrNull(offsets[5]);
  object.radical = reader.readStringOrNull(offsets[6]);
  object.strokeCount = reader.readLongOrNull(offsets[7]);
  object.strokes = reader.readStringList(offsets[8]) ?? [];
  object.updatedAt = reader.readDateTime(offsets[9]);
  return object;
}

P _characterIsarModelDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readString(offset)) as P;
    case 1:
      return (reader.readStringOrNull(offset)) as P;
    case 2:
      return (reader.readStringOrNull(offset)) as P;
    case 3:
      return (reader.readLongOrNull(offset)) as P;
    case 4:
      return (reader.readStringOrNull(offset)) as P;
    case 5:
      return (reader.readStringOrNull(offset)) as P;
    case 6:
      return (reader.readStringOrNull(offset)) as P;
    case 7:
      return (reader.readLongOrNull(offset)) as P;
    case 8:
      return (reader.readStringList(offset) ?? []) as P;
    case 9:
      return (reader.readDateTime(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _characterIsarModelGetId(CharacterIsarModel object) {
  return object.isarId;
}

List<IsarLinkBase<dynamic>> _characterIsarModelGetLinks(
  CharacterIsarModel object,
) {
  return [];
}

void _characterIsarModelAttach(
  IsarCollection<dynamic> col,
  Id id,
  CharacterIsarModel object,
) {
  object.isarId = id;
}

extension CharacterIsarModelByIndex on IsarCollection<CharacterIsarModel> {
  Future<CharacterIsarModel?> getByChar(String char) {
    return getByIndex(r'char', [char]);
  }

  CharacterIsarModel? getByCharSync(String char) {
    return getByIndexSync(r'char', [char]);
  }

  Future<bool> deleteByChar(String char) {
    return deleteByIndex(r'char', [char]);
  }

  bool deleteByCharSync(String char) {
    return deleteByIndexSync(r'char', [char]);
  }

  Future<List<CharacterIsarModel?>> getAllByChar(List<String> charValues) {
    final values = charValues.map((e) => [e]).toList();
    return getAllByIndex(r'char', values);
  }

  List<CharacterIsarModel?> getAllByCharSync(List<String> charValues) {
    final values = charValues.map((e) => [e]).toList();
    return getAllByIndexSync(r'char', values);
  }

  Future<int> deleteAllByChar(List<String> charValues) {
    final values = charValues.map((e) => [e]).toList();
    return deleteAllByIndex(r'char', values);
  }

  int deleteAllByCharSync(List<String> charValues) {
    final values = charValues.map((e) => [e]).toList();
    return deleteAllByIndexSync(r'char', values);
  }

  Future<Id> putByChar(CharacterIsarModel object) {
    return putByIndex(r'char', object);
  }

  Id putByCharSync(CharacterIsarModel object, {bool saveLinks = true}) {
    return putByIndexSync(r'char', object, saveLinks: saveLinks);
  }

  Future<List<Id>> putAllByChar(List<CharacterIsarModel> objects) {
    return putAllByIndex(r'char', objects);
  }

  List<Id> putAllByCharSync(
    List<CharacterIsarModel> objects, {
    bool saveLinks = true,
  }) {
    return putAllByIndexSync(r'char', objects, saveLinks: saveLinks);
  }
}

extension CharacterIsarModelQueryWhereSort
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QWhere> {
  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhere>
  anyIsarId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhere>
  anyUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'updatedAt'),
      );
    });
  }
}

extension CharacterIsarModelQueryWhere
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QWhereClause> {
  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  isarIdEqualTo(Id isarId) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.between(lower: isarId, upper: isarId),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  isarIdNotEqualTo(Id isarId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: isarId, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: isarId, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: isarId, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: isarId, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  isarIdGreaterThan(Id isarId, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: isarId, includeLower: include),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  isarIdLessThan(Id isarId, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: isarId, includeUpper: include),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  isarIdBetween(
    Id lowerIsarId,
    Id upperIsarId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.between(
          lower: lowerIsarId,
          includeLower: includeLower,
          upper: upperIsarId,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  charEqualTo(String char) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'char', value: [char]),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  charNotEqualTo(String char) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'char',
                lower: [],
                upper: [char],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'char',
                lower: [char],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'char',
                lower: [char],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'char',
                lower: [],
                upper: [char],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  pinyinNormalizedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'pinyinNormalized', value: [null]),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  pinyinNormalizedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'pinyinNormalized',
          lower: [null],
          includeLower: false,
          upper: [],
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  pinyinNormalizedEqualTo(String? pinyinNormalized) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(
          indexName: r'pinyinNormalized',
          value: [pinyinNormalized],
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  pinyinNormalizedNotEqualTo(String? pinyinNormalized) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [],
                upper: [pinyinNormalized],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [pinyinNormalized],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [pinyinNormalized],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [],
                upper: [pinyinNormalized],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  updatedAtEqualTo(DateTime updatedAt) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'updatedAt', value: [updatedAt]),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  updatedAtNotEqualTo(DateTime updatedAt) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'updatedAt',
                lower: [],
                upper: [updatedAt],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'updatedAt',
                lower: [updatedAt],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'updatedAt',
                lower: [updatedAt],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'updatedAt',
                lower: [],
                upper: [updatedAt],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  updatedAtGreaterThan(DateTime updatedAt, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'updatedAt',
          lower: [updatedAt],
          includeLower: include,
          upper: [],
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  updatedAtLessThan(DateTime updatedAt, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'updatedAt',
          lower: [],
          upper: [updatedAt],
          includeUpper: include,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterWhereClause>
  updatedAtBetween(
    DateTime lowerUpdatedAt,
    DateTime upperUpdatedAt, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'updatedAt',
          lower: [lowerUpdatedAt],
          includeLower: includeLower,
          upper: [upperUpdatedAt],
          includeUpper: includeUpper,
        ),
      );
    });
  }
}

extension CharacterIsarModelQueryFilter
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QFilterCondition> {
  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'char',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'char',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'char',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'char',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'char',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'char',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'char',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'char',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'char', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  charIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'char', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'definition'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'definition'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionEqualTo(String? value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'definition',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'definition',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'definition',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'definition',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'definition',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'definition',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'definition',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'definition',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'definition', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'definition', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'definitionVi'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'definitionVi'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViEqualTo(String? value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'definitionVi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'definitionVi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'definitionVi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'definitionVi',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'definitionVi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'definitionVi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'definitionVi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'definitionVi',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'definitionVi', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  definitionViIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'definitionVi', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  hskLevelIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'hskLevel'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  hskLevelIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'hskLevel'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  hskLevelEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'hskLevel', value: value),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  hskLevelGreaterThan(int? value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'hskLevel',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  hskLevelLessThan(int? value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'hskLevel',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  hskLevelBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'hskLevel',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  isarIdEqualTo(Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'isarId', value: value),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  isarIdGreaterThan(Id value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'isarId',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  isarIdLessThan(Id value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'isarId',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  isarIdBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'isarId',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'pinyin'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'pinyin'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinEqualTo(String? value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'pinyin',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'pinyin',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'pinyin', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'pinyin', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'pinyinNormalized'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'pinyinNormalized'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedEqualTo(String? value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'pinyinNormalized',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'pinyinNormalized',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'pinyinNormalized', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  pinyinNormalizedIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'pinyinNormalized', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'radical'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'radical'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalEqualTo(String? value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'radical',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'radical',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'radical',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'radical',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'radical',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'radical',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'radical',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'radical',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'radical', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  radicalIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'radical', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokeCountIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'strokeCount'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokeCountIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'strokeCount'),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokeCountEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'strokeCount', value: value),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokeCountGreaterThan(int? value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'strokeCount',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokeCountLessThan(int? value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'strokeCount',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokeCountBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'strokeCount',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'strokes',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'strokes',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'strokes',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'strokes',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'strokes',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'strokes',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'strokes',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'strokes',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'strokes', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'strokes', value: ''),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'strokes', length, true, length, true);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'strokes', 0, true, 0, true);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'strokes', 0, false, 999999, true);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesLengthLessThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'strokes', 0, true, length, include);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesLengthGreaterThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'strokes', length, include, 999999, true);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  strokesLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'strokes',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  updatedAtEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'updatedAt', value: value),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  updatedAtGreaterThan(DateTime value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'updatedAt',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  updatedAtLessThan(DateTime value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'updatedAt',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterFilterCondition>
  updatedAtBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'updatedAt',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }
}

extension CharacterIsarModelQueryObject
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QFilterCondition> {}

extension CharacterIsarModelQueryLinks
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QFilterCondition> {}

extension CharacterIsarModelQuerySortBy
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QSortBy> {
  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByChar() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'char', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByCharDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'char', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByDefinition() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definition', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByDefinitionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definition', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByDefinitionVi() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definitionVi', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByDefinitionViDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definitionVi', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByHskLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hskLevel', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByHskLevelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hskLevel', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByPinyin() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByPinyinDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByPinyinNormalized() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByPinyinNormalizedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByRadical() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'radical', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByRadicalDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'radical', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByStrokeCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'strokeCount', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByStrokeCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'strokeCount', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  sortByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }
}

extension CharacterIsarModelQuerySortThenBy
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QSortThenBy> {
  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByChar() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'char', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByCharDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'char', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByDefinition() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definition', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByDefinitionDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definition', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByDefinitionVi() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definitionVi', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByDefinitionViDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'definitionVi', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByHskLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hskLevel', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByHskLevelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hskLevel', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByIsarId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isarId', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByIsarIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isarId', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByPinyin() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByPinyinDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByPinyinNormalized() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByPinyinNormalizedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByRadical() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'radical', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByRadicalDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'radical', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByStrokeCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'strokeCount', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByStrokeCountDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'strokeCount', Sort.desc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QAfterSortBy>
  thenByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }
}

extension CharacterIsarModelQueryWhereDistinct
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct> {
  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByChar({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'char', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByDefinition({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'definition', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByDefinitionVi({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'definitionVi', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByHskLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'hskLevel');
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByPinyin({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'pinyin', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByPinyinNormalized({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(
        r'pinyinNormalized',
        caseSensitive: caseSensitive,
      );
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByRadical({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'radical', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByStrokeCount() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'strokeCount');
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByStrokes() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'strokes');
    });
  }

  QueryBuilder<CharacterIsarModel, CharacterIsarModel, QDistinct>
  distinctByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'updatedAt');
    });
  }
}

extension CharacterIsarModelQueryProperty
    on QueryBuilder<CharacterIsarModel, CharacterIsarModel, QQueryProperty> {
  QueryBuilder<CharacterIsarModel, int, QQueryOperations> isarIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isarId');
    });
  }

  QueryBuilder<CharacterIsarModel, String, QQueryOperations> charProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'char');
    });
  }

  QueryBuilder<CharacterIsarModel, String?, QQueryOperations>
  definitionProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'definition');
    });
  }

  QueryBuilder<CharacterIsarModel, String?, QQueryOperations>
  definitionViProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'definitionVi');
    });
  }

  QueryBuilder<CharacterIsarModel, int?, QQueryOperations> hskLevelProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'hskLevel');
    });
  }

  QueryBuilder<CharacterIsarModel, String?, QQueryOperations> pinyinProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'pinyin');
    });
  }

  QueryBuilder<CharacterIsarModel, String?, QQueryOperations>
  pinyinNormalizedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'pinyinNormalized');
    });
  }

  QueryBuilder<CharacterIsarModel, String?, QQueryOperations>
  radicalProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'radical');
    });
  }

  QueryBuilder<CharacterIsarModel, int?, QQueryOperations>
  strokeCountProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'strokeCount');
    });
  }

  QueryBuilder<CharacterIsarModel, List<String>, QQueryOperations>
  strokesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'strokes');
    });
  }

  QueryBuilder<CharacterIsarModel, DateTime, QQueryOperations>
  updatedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'updatedAt');
    });
  }
}
