// ignore_for_file: experimental_member_use
import 'package:isar_community/isar.dart';

part 'character_isar_model.g.dart';

// ============================================================================
// Collection: CharacterIsarModel
// Mỗi document = 1 chữ Hán duy nhất với dữ liệu stroke animation.
// ============================================================================
@collection
class CharacterIsarModel {
  Id isarId = Isar.autoIncrement;

  /// Chữ Hán (e.g. "学")
  @Index(unique: true, replace: true)
  late String char;

  /// Danh sách SVG path cho mỗi nét vẽ
  late List<String> strokes;

  /// HSK level nếu chữ này xuất hiện độc lập trong HSK
  int? hskLevel;

  /// Bộ thủ (radical), e.g. "亻"
  String? radical;

  /// Số nét tổng cộng
  int? strokeCount;

  /// Pinyin phổ biến nhất của chữ, e.g. "xué"
  String? pinyin;

  /// Pinyin không dấu để search, e.g. "xue"
  @Index()
  String? pinyinNormalized;

  /// Nghĩa tiếng Anh ngắn
  String? definition;

  /// Nghĩa tiếng Việt ngắn
  String? definitionVi;

  /// Thời điểm cập nhật (dùng cho sync sau này)
  @Index()
  late DateTime updatedAt;

  CharacterIsarModel();

  // ── fromJson ───────────────────────────────────────────────────────────────

  static CharacterIsarModel fromJson(Map<String, dynamic> json) {
    // Support cả field 'char' (guide) và 'character' (phase 1 sample)
    final charVal = json['char'] as String? ??
        json['character'] as String? ?? '';

    final pinyinVal = json['pinyin'] as String?;
    final pinyinNorm = json['pinyinNormalized'] as String? ??
        (pinyinVal != null ? _normalizePinyinLocal(pinyinVal) : null);

    final rawStrokes = json['strokes'] as List? ?? [];
    // strokes có thể là List<String> hoặc List<Map> {path, order}
    final strokes = rawStrokes.map((s) {
      if (s is String) return s;
      if (s is Map) return s['path'] as String? ?? '';
      return '';
    }).where((s) => s.isNotEmpty).toList();

    return CharacterIsarModel()
      ..char = charVal
      ..strokes = strokes
      ..hskLevel = json['hskLevel'] as int? ?? json['level'] as int?
      ..radical = json['radical'] as String?
      ..strokeCount = json['strokeCount'] as int? ?? strokes.length
      ..pinyin = pinyinVal
      ..pinyinNormalized = pinyinNorm
      ..definition = json['definition'] as String?
      ..definitionVi = json['definitionVi'] as String?
      ..updatedAt = DateTime.now().toUtc();
  }

  // ── toJson ────────────────────────────────────────────────────────────────

  Map<String, dynamic> toJson() => {
    'char': char,
    'strokes': strokes,
    'hskLevel': hskLevel,
    'radical': radical,
    'strokeCount': strokeCount,
    'pinyin': pinyin,
    'pinyinNormalized': pinyinNormalized,
    'definition': definition,
    'definitionVi': definitionVi,
  };

  // ── helper ─────────────────────────────────────────────────────────────────

  static String _normalizePinyinLocal(String pinyin) {
    const toneMap = {
      'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
      'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
      'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
      'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
      'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
      'ǖ': 'v', 'ǘ': 'v', 'ǚ': 'v', 'ǜ': 'v', 'ü': 'v',
    };
    var result = pinyin.toLowerCase();
    toneMap.forEach((t, p) => result = result.replaceAll(t, p));
    return result.replaceAll(RegExp(r'[\s\d]'), '');
  }
}
