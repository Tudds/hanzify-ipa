import '../../domain/entities/vocab.dart';
import '../../domain/repositories/vocab_repository.dart';
import '../datasources/vocab_local_datasource.dart';
import '../models/vocab_isar_model.dart';

class VocabRepositoryImpl implements VocabRepository {
  final VocabLocalDataSource localDataSource;
  VocabRepositoryImpl(this.localDataSource);

  @override
  Future<List<Vocab>> getAll() async {
    final models = await localDataSource.getAll();
    return models.map((m) => m.toEntity()).toList();
  }

  @override
  Future<List<Vocab>> getDue() async {
    final models = await localDataSource.getDue();
    return models.map((m) => m.toEntity()).toList();
  }

  @override
  Future<List<Vocab>> getByLevel(int level) async {
    final models = await localDataSource.getByLevel(level);
    return models.map((m) => m.toEntity()).toList();
  }

  @override
  Future<void> update(Vocab vocab) async {
    await localDataSource.update(VocabIsarModel.fromEntity(vocab));
  }

  @override
  Future<void> save(Vocab vocab) async {
    await localDataSource.insert(VocabIsarModel.fromEntity(vocab));
  }

  @override
  Future<List<Vocab>> search(
    String query, {
    int? hskLevel,
    String? wordType,
  }) async {
    final models = await localDataSource.search(
      query,
      hskLevel: hskLevel,
      wordType: wordType,
    );
    return models.map((m) => m.toEntity()).toList();
  }
}
