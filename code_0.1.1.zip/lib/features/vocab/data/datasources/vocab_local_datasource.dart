import '../models/vocab_isar_model.dart';

abstract class VocabLocalDataSource {
  Future<List<VocabIsarModel>> getAll();
  Future<List<VocabIsarModel>> getDue();
  Future<void> update(VocabIsarModel model);
  Future<void> insert(VocabIsarModel model);

  /// Tìm kiếm theo hanzi, pinyin (có và không dấu), hoặc nghĩa tiếng Việt.
  Future<List<VocabIsarModel>> search(
    String query, {
    int? hskLevel,
    String? wordType,
  });

  /// Lấy danh sách vocab theo HSK level.
  Future<List<VocabIsarModel>> getByLevel(int level);
}
