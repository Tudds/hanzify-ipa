// lib/features/vocab/presentation/providers/vocab_search_provider.dart
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/vocab.dart';
import 'vocab_providers.dart';
import '../../data/datasources/vocab_local_datasource_impl.dart' show normalizePinyin;

part 'vocab_search_provider.g.dart';

// ============================================================================
// normalizePinyinSearch
// Dùng cùng logic với hàm normalizePinyin trong datasource impl.
// Export ra để UI có thể gọi trực tiếp khi cần.
// ============================================================================
String normalizePinyinSearch(String input) => normalizePinyin(input.trim());

// ============================================================================
// searchVocabProvider
// Provider chính cho search — dùng repository (thay vì gọi Isar trực tiếp)
// để đảm bảo data đi qua đúng layer.
// ============================================================================
@riverpod
Future<List<Vocab>> searchVocab(
  Ref ref,
  String query, {
  int? hskLevel,
  String? wordType,
}) async {
  final repository = ref.watch(vocabRepositoryProvider);

  return repository.search(
    query,
    hskLevel: hskLevel,
    wordType: wordType,
  );
}

// ============================================================================
// vocabByLevelProvider
// Lấy danh sách vocab của một HSK level cụ thể.
// ============================================================================
@riverpod
Future<List<Vocab>> vocabByLevel(Ref ref, int level) async {
  final repository = ref.watch(vocabRepositoryProvider);
  return repository.getByLevel(level);
}
