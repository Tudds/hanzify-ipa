import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../domain/entities/vocab.dart';
import 'package:hanzify/core/theme/colors.dart';
import 'package:hanzify/core/theme/typography.dart';

// ── POS colour mapping ─────────────────────────────────────────────────────
const _posColors = <String, Color>{
  'v': Color(0xFF3B82F6), // blue  – động từ
  'n': Color(0xFF10B981), // green – danh từ
  'adj': Color(0xFFF59E0B), // amber – tính từ
  'adv': Color(0xFF8B5CF6), // purple – trạng từ
  'prep': Color(0xFFEF4444), // red   – giới từ
  'conj': Color(0xFFEC4899), // pink  – liên từ
  'pron': Color(0xFF06B6D4), // cyan  – đại từ
  'num': Color(0xFF84CC16), // lime  – số từ
  'mw': Color(0xFF6366F1), // indigo – lượng từ
  'aux': Color(0xFFF97316), // orange – trợ động từ
  'interj': Color(0xFF14B8A6), // teal  – thán từ
};

const _posLabels = <String, String>{
  'v': 'Động từ (动词)',
  'n': 'Danh từ (名词)',
  'adj': 'Tính từ (形容词)',
  'adv': 'Trạng từ (副词)',
  'prep': 'Giới từ (介词)',
  'conj': 'Liên từ (连词)',
  'pron': 'Đại từ (代词)',
  'num': 'Số từ (数词)',
  'mw': 'Lượng từ (量词)',
  'aux': 'Trợ từ (助词)',
  'interj': 'Thán từ (叹词)',
  'other': 'Khác (其他)',
};

Color _posColor(String pos) => _posColors[pos] ?? const Color(0xFF9CA3AF);
String _posLabel(String pos) => _posLabels[pos] ?? pos;

// ── Widget ─────────────────────────────────────────────────────────────────

class VocabCardWidget extends StatefulWidget {
  final Vocab item;
  final AppThemeColors colors;

  const VocabCardWidget({super.key, required this.item, required this.colors});

  @override
  State<VocabCardWidget> createState() => _VocabCardWidgetState();
}

class _VocabCardWidgetState extends State<VocabCardWidget>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  late AnimationController _scaleCtrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _scaleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scale = Tween<double>(begin: 1.0, end: 0.97).animate(_scaleCtrl);
  }

  @override
  void dispose() {
    _scaleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    final item = widget.item;
    final hasMeanings = item.meanings.isNotEmpty;
    final hasExamples = item.exampleSentences.isNotEmpty;

    return ScaleTransition(
      scale: _scale,
      child: GestureDetector(
        onTapDown: (_) => _scaleCtrl.forward(),
        onTapUp: (_) {
          _scaleCtrl.reverse();
          setState(() => _expanded = !_expanded);
        },
        onTapCancel: () => _scaleCtrl.reverse(),
        child: Container(
          margin: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: c.surface,
            borderRadius: BorderRadius.circular(AppRadii.xl),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header row ─────────────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Text(
                          item.hanzi,
                          style: GoogleFonts.notoSansSc(
                            fontSize: 32,
                            fontWeight: FontWeight.w700,
                            color: c.text,
                          ),
                        ),
                        if (item.isMastered)
                          const Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: Icon(
                              Icons.check_circle,
                              color: Color(0xFF10B981),
                              size: 20,
                            ),
                          ),
                        if (item.isBookmarked)
                          Padding(
                            padding: const EdgeInsets.only(left: 4),
                            child: Icon(
                              Icons.bookmark,
                              color: c.primary,
                              size: 20,
                            ),
                          ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: c.accent.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'HSK ${item.level}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: c.accent,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 4),

                // ── Pinyin ────────────────────────────────────────────
                Text(
                  item.pinyin,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    color: c.primary,
                  ),
                ),

                const SizedBox(height: 8),

                // ── Meanings with POS tags ────────────────────────────
                if (hasMeanings)
                  ..._buildMeanings(item.meanings, c)
                else
                  Text(
                    item.meaning.replaceFirst(RegExp(r'^[a-z]+\.\s*'), ''),
                    style: TextStyle(fontSize: 15, color: c.placeholder),
                  ),

                // ── Expandable section ────────────────────────────────
                AnimatedSize(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeInOut,
                  child: _expanded
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (hasExamples) ...[
                              const SizedBox(height: 12),
                              Divider(color: c.disabled.withValues(alpha: 0.4)),
                              const SizedBox(height: 6),
                              Text(
                                'Ví dụ:',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: c.accent,
                                ),
                              ),
                              const SizedBox(height: 6),
                              ..._buildExamples(item.exampleSentences, c),
                            ] else if (item.exampleSentences.isEmpty &&
                                item.meanings.isEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  'Chưa có ví dụ.',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: c.disabled,
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              ),

                            // ── Character breakdown ─────────────────
                            if (item.characters.length > 1) ...[
                              const SizedBox(height: 10),
                              _buildCharacterRow(item.characters, c),
                            ],
                          ],
                        )
                      : const SizedBox.shrink(),
                ),

                const SizedBox(height: 8),

                // ── Toggle label ──────────────────────────────────────
                Center(
                  child: Text(
                    _expanded ? '▲ Thu gọn' : '▼ Xem thêm',
                    style: TextStyle(fontSize: 12, color: c.disabled),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Builders ──────────────────────────────────────────────────────────────

  List<Widget> _buildMeanings(List<Meaning> meanings, AppThemeColors c) {
    return meanings.map((m) {
      final color = _posColor(m.pos);
      final label = _posLabel(m.pos);
      return Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: color.withValues(alpha: 0.5)),
              ),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: color,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                m.vi,
                style: TextStyle(fontSize: 15, color: c.text, height: 1.4),
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  List<Widget> _buildExamples(
    List<ExampleSentence> examples,
    AppThemeColors c,
  ) {
    return examples.map((e) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('• ', style: TextStyle(color: c.accent, fontSize: 14)),
                Expanded(
                  child: Text(
                    e.cn,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: c.text,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
            if (e.pinyin.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Text(
                  e.pinyin,
                  style: TextStyle(fontSize: 13, color: c.primary, height: 1.4),
                ),
              ),
            if (e.vi.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Text(
                  e.vi,
                  style: TextStyle(
                    fontSize: 13,
                    color: c.placeholder,
                    height: 1.4,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
          ],
        ),
      );
    }).toList();
  }

  Widget _buildCharacterRow(List<String> chars, AppThemeColors c) {
    return Wrap(
      spacing: 6,
      children: chars
          .map(
            (ch) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: c.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: c.primary.withValues(alpha: 0.3)),
              ),
              child: Text(
                ch,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: c.primary,
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}
