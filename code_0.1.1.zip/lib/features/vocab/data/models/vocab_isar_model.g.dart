// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vocab_isar_model.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetVocabIsarModelCollection on Isar {
  IsarCollection<VocabIsarModel> get vocabIsarModels => this.collection();
}

const VocabIsarModelSchema = CollectionSchema(
  name: r'VocabIsarModel',
  id: 8678492416206557680,
  properties: {
    r'characters': PropertySchema(
      id: 0,
      name: r'characters',
      type: IsarType.stringList,
    ),
    r'easeFactor': PropertySchema(
      id: 1,
      name: r'easeFactor',
      type: IsarType.double,
    ),
    r'exampleSentences': PropertySchema(
      id: 2,
      name: r'exampleSentences',
      type: IsarType.objectList,

      target: r'ExampleSentenceEmbedded',
    ),
    r'hanzi': PropertySchema(id: 3, name: r'hanzi', type: IsarType.string),
    r'id': PropertySchema(id: 4, name: r'id', type: IsarType.string),
    r'interval': PropertySchema(id: 5, name: r'interval', type: IsarType.long),
    r'isBookmarked': PropertySchema(
      id: 6,
      name: r'isBookmarked',
      type: IsarType.bool,
    ),
    r'isMastered': PropertySchema(
      id: 7,
      name: r'isMastered',
      type: IsarType.bool,
    ),
    r'level': PropertySchema(id: 8, name: r'level', type: IsarType.long),
    r'meaning': PropertySchema(id: 9, name: r'meaning', type: IsarType.string),
    r'meanings': PropertySchema(
      id: 10,
      name: r'meanings',
      type: IsarType.objectList,

      target: r'MeaningEmbedded',
    ),
    r'needsSync': PropertySchema(
      id: 11,
      name: r'needsSync',
      type: IsarType.bool,
    ),
    r'nextReview': PropertySchema(
      id: 12,
      name: r'nextReview',
      type: IsarType.dateTime,
    ),
    r'pinyin': PropertySchema(id: 13, name: r'pinyin', type: IsarType.string),
    r'pinyinNormalized': PropertySchema(
      id: 14,
      name: r'pinyinNormalized',
      type: IsarType.string,
    ),
    r'repetitions': PropertySchema(
      id: 15,
      name: r'repetitions',
      type: IsarType.long,
    ),
    r'updatedAt': PropertySchema(
      id: 16,
      name: r'updatedAt',
      type: IsarType.dateTime,
    ),
    r'wordType': PropertySchema(
      id: 17,
      name: r'wordType',
      type: IsarType.string,
    ),
  },

  estimateSize: _vocabIsarModelEstimateSize,
  serialize: _vocabIsarModelSerialize,
  deserialize: _vocabIsarModelDeserialize,
  deserializeProp: _vocabIsarModelDeserializeProp,
  idName: r'isarId',
  indexes: {
    r'id': IndexSchema(
      id: -3268401673993471357,
      name: r'id',
      unique: true,
      replace: true,
      properties: [
        IndexPropertySchema(
          name: r'id',
          type: IndexType.hash,
          caseSensitive: true,
        ),
      ],
    ),
    r'hanzi': IndexSchema(
      id: 8791959352564742387,
      name: r'hanzi',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'hanzi',
          type: IndexType.value,
          caseSensitive: true,
        ),
      ],
    ),
    r'pinyinNormalized': IndexSchema(
      id: -5792813043327382502,
      name: r'pinyinNormalized',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'pinyinNormalized',
          type: IndexType.value,
          caseSensitive: true,
        ),
      ],
    ),
    r'level': IndexSchema(
      id: -730704511986726349,
      name: r'level',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'level',
          type: IndexType.value,
          caseSensitive: false,
        ),
      ],
    ),
    r'wordType': IndexSchema(
      id: -815241636931347329,
      name: r'wordType',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'wordType',
          type: IndexType.hash,
          caseSensitive: true,
        ),
      ],
    ),
    r'nextReview': IndexSchema(
      id: 316564737852968787,
      name: r'nextReview',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'nextReview',
          type: IndexType.value,
          caseSensitive: false,
        ),
      ],
    ),
    r'needsSync': IndexSchema(
      id: 582046641891238027,
      name: r'needsSync',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'needsSync',
          type: IndexType.value,
          caseSensitive: false,
        ),
      ],
    ),
  },
  links: {},
  embeddedSchemas: {
    r'MeaningEmbedded': MeaningEmbeddedSchema,
    r'ExampleSentenceEmbedded': ExampleSentenceEmbeddedSchema,
  },

  getId: _vocabIsarModelGetId,
  getLinks: _vocabIsarModelGetLinks,
  attach: _vocabIsarModelAttach,
  version: '3.3.2',
);

int _vocabIsarModelEstimateSize(
  VocabIsarModel object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.characters.length * 3;
  {
    for (var i = 0; i < object.characters.length; i++) {
      final value = object.characters[i];
      bytesCount += value.length * 3;
    }
  }
  bytesCount += 3 + object.exampleSentences.length * 3;
  {
    final offsets = allOffsets[ExampleSentenceEmbedded]!;
    for (var i = 0; i < object.exampleSentences.length; i++) {
      final value = object.exampleSentences[i];
      bytesCount += ExampleSentenceEmbeddedSchema.estimateSize(
        value,
        offsets,
        allOffsets,
      );
    }
  }
  bytesCount += 3 + object.hanzi.length * 3;
  bytesCount += 3 + object.id.length * 3;
  bytesCount += 3 + object.meaning.length * 3;
  bytesCount += 3 + object.meanings.length * 3;
  {
    final offsets = allOffsets[MeaningEmbedded]!;
    for (var i = 0; i < object.meanings.length; i++) {
      final value = object.meanings[i];
      bytesCount += MeaningEmbeddedSchema.estimateSize(
        value,
        offsets,
        allOffsets,
      );
    }
  }
  bytesCount += 3 + object.pinyin.length * 3;
  bytesCount += 3 + object.pinyinNormalized.length * 3;
  bytesCount += 3 + object.wordType.length * 3;
  return bytesCount;
}

void _vocabIsarModelSerialize(
  VocabIsarModel object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeStringList(offsets[0], object.characters);
  writer.writeDouble(offsets[1], object.easeFactor);
  writer.writeObjectList<ExampleSentenceEmbedded>(
    offsets[2],
    allOffsets,
    ExampleSentenceEmbeddedSchema.serialize,
    object.exampleSentences,
  );
  writer.writeString(offsets[3], object.hanzi);
  writer.writeString(offsets[4], object.id);
  writer.writeLong(offsets[5], object.interval);
  writer.writeBool(offsets[6], object.isBookmarked);
  writer.writeBool(offsets[7], object.isMastered);
  writer.writeLong(offsets[8], object.level);
  writer.writeString(offsets[9], object.meaning);
  writer.writeObjectList<MeaningEmbedded>(
    offsets[10],
    allOffsets,
    MeaningEmbeddedSchema.serialize,
    object.meanings,
  );
  writer.writeBool(offsets[11], object.needsSync);
  writer.writeDateTime(offsets[12], object.nextReview);
  writer.writeString(offsets[13], object.pinyin);
  writer.writeString(offsets[14], object.pinyinNormalized);
  writer.writeLong(offsets[15], object.repetitions);
  writer.writeDateTime(offsets[16], object.updatedAt);
  writer.writeString(offsets[17], object.wordType);
}

VocabIsarModel _vocabIsarModelDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = VocabIsarModel();
  object.characters = reader.readStringList(offsets[0]) ?? [];
  object.easeFactor = reader.readDouble(offsets[1]);
  object.exampleSentences =
      reader.readObjectList<ExampleSentenceEmbedded>(
        offsets[2],
        ExampleSentenceEmbeddedSchema.deserialize,
        allOffsets,
        ExampleSentenceEmbedded(),
      ) ??
      [];
  object.hanzi = reader.readString(offsets[3]);
  object.id = reader.readString(offsets[4]);
  object.interval = reader.readLong(offsets[5]);
  object.isBookmarked = reader.readBool(offsets[6]);
  object.isMastered = reader.readBool(offsets[7]);
  object.isarId = id;
  object.level = reader.readLong(offsets[8]);
  object.meaning = reader.readString(offsets[9]);
  object.meanings =
      reader.readObjectList<MeaningEmbedded>(
        offsets[10],
        MeaningEmbeddedSchema.deserialize,
        allOffsets,
        MeaningEmbedded(),
      ) ??
      [];
  object.needsSync = reader.readBool(offsets[11]);
  object.nextReview = reader.readDateTime(offsets[12]);
  object.pinyin = reader.readString(offsets[13]);
  object.pinyinNormalized = reader.readString(offsets[14]);
  object.repetitions = reader.readLong(offsets[15]);
  object.updatedAt = reader.readDateTime(offsets[16]);
  object.wordType = reader.readString(offsets[17]);
  return object;
}

P _vocabIsarModelDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readStringList(offset) ?? []) as P;
    case 1:
      return (reader.readDouble(offset)) as P;
    case 2:
      return (reader.readObjectList<ExampleSentenceEmbedded>(
                offset,
                ExampleSentenceEmbeddedSchema.deserialize,
                allOffsets,
                ExampleSentenceEmbedded(),
              ) ??
              [])
          as P;
    case 3:
      return (reader.readString(offset)) as P;
    case 4:
      return (reader.readString(offset)) as P;
    case 5:
      return (reader.readLong(offset)) as P;
    case 6:
      return (reader.readBool(offset)) as P;
    case 7:
      return (reader.readBool(offset)) as P;
    case 8:
      return (reader.readLong(offset)) as P;
    case 9:
      return (reader.readString(offset)) as P;
    case 10:
      return (reader.readObjectList<MeaningEmbedded>(
                offset,
                MeaningEmbeddedSchema.deserialize,
                allOffsets,
                MeaningEmbedded(),
              ) ??
              [])
          as P;
    case 11:
      return (reader.readBool(offset)) as P;
    case 12:
      return (reader.readDateTime(offset)) as P;
    case 13:
      return (reader.readString(offset)) as P;
    case 14:
      return (reader.readString(offset)) as P;
    case 15:
      return (reader.readLong(offset)) as P;
    case 16:
      return (reader.readDateTime(offset)) as P;
    case 17:
      return (reader.readString(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _vocabIsarModelGetId(VocabIsarModel object) {
  return object.isarId;
}

List<IsarLinkBase<dynamic>> _vocabIsarModelGetLinks(VocabIsarModel object) {
  return [];
}

void _vocabIsarModelAttach(
  IsarCollection<dynamic> col,
  Id id,
  VocabIsarModel object,
) {
  object.isarId = id;
}

extension VocabIsarModelByIndex on IsarCollection<VocabIsarModel> {
  Future<VocabIsarModel?> getById(String id) {
    return getByIndex(r'id', [id]);
  }

  VocabIsarModel? getByIdSync(String id) {
    return getByIndexSync(r'id', [id]);
  }

  Future<bool> deleteById(String id) {
    return deleteByIndex(r'id', [id]);
  }

  bool deleteByIdSync(String id) {
    return deleteByIndexSync(r'id', [id]);
  }

  Future<List<VocabIsarModel?>> getAllById(List<String> idValues) {
    final values = idValues.map((e) => [e]).toList();
    return getAllByIndex(r'id', values);
  }

  List<VocabIsarModel?> getAllByIdSync(List<String> idValues) {
    final values = idValues.map((e) => [e]).toList();
    return getAllByIndexSync(r'id', values);
  }

  Future<int> deleteAllById(List<String> idValues) {
    final values = idValues.map((e) => [e]).toList();
    return deleteAllByIndex(r'id', values);
  }

  int deleteAllByIdSync(List<String> idValues) {
    final values = idValues.map((e) => [e]).toList();
    return deleteAllByIndexSync(r'id', values);
  }

  Future<Id> putById(VocabIsarModel object) {
    return putByIndex(r'id', object);
  }

  Id putByIdSync(VocabIsarModel object, {bool saveLinks = true}) {
    return putByIndexSync(r'id', object, saveLinks: saveLinks);
  }

  Future<List<Id>> putAllById(List<VocabIsarModel> objects) {
    return putAllByIndex(r'id', objects);
  }

  List<Id> putAllByIdSync(
    List<VocabIsarModel> objects, {
    bool saveLinks = true,
  }) {
    return putAllByIndexSync(r'id', objects, saveLinks: saveLinks);
  }
}

extension VocabIsarModelQueryWhereSort
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QWhere> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhere> anyIsarId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhere> anyHanzi() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'hanzi'),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhere>
  anyPinyinNormalized() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'pinyinNormalized'),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhere> anyLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'level'),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhere> anyNextReview() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'nextReview'),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhere> anyNeedsSync() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'needsSync'),
      );
    });
  }
}

extension VocabIsarModelQueryWhere
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QWhereClause> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> isarIdEqualTo(
    Id isarId,
  ) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.between(lower: isarId, upper: isarId),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  isarIdNotEqualTo(Id isarId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: isarId, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: isarId, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: isarId, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: isarId, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  isarIdGreaterThan(Id isarId, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: isarId, includeLower: include),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  isarIdLessThan(Id isarId, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: isarId, includeUpper: include),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> isarIdBetween(
    Id lowerIsarId,
    Id upperIsarId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.between(
          lower: lowerIsarId,
          includeLower: includeLower,
          upper: upperIsarId,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> idEqualTo(
    String id,
  ) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'id', value: [id]),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> idNotEqualTo(
    String id,
  ) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'id',
                lower: [],
                upper: [id],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'id',
                lower: [id],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'id',
                lower: [id],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'id',
                lower: [],
                upper: [id],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> hanziEqualTo(
    String hanzi,
  ) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'hanzi', value: [hanzi]),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  hanziNotEqualTo(String hanzi) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'hanzi',
                lower: [],
                upper: [hanzi],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'hanzi',
                lower: [hanzi],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'hanzi',
                lower: [hanzi],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'hanzi',
                lower: [],
                upper: [hanzi],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  hanziGreaterThan(String hanzi, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'hanzi',
          lower: [hanzi],
          includeLower: include,
          upper: [],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> hanziLessThan(
    String hanzi, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'hanzi',
          lower: [],
          upper: [hanzi],
          includeUpper: include,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> hanziBetween(
    String lowerHanzi,
    String upperHanzi, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'hanzi',
          lower: [lowerHanzi],
          includeLower: includeLower,
          upper: [upperHanzi],
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  hanziStartsWith(String HanziPrefix) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'hanzi',
          lower: [HanziPrefix],
          upper: ['$HanziPrefix\u{FFFFF}'],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  hanziIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'hanzi', value: ['']),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  hanziIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.lessThan(indexName: r'hanzi', upper: ['']),
            )
            .addWhereClause(
              IndexWhereClause.greaterThan(indexName: r'hanzi', lower: ['']),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.greaterThan(indexName: r'hanzi', lower: ['']),
            )
            .addWhereClause(
              IndexWhereClause.lessThan(indexName: r'hanzi', upper: ['']),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedEqualTo(String pinyinNormalized) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(
          indexName: r'pinyinNormalized',
          value: [pinyinNormalized],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedNotEqualTo(String pinyinNormalized) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [],
                upper: [pinyinNormalized],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [pinyinNormalized],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [pinyinNormalized],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'pinyinNormalized',
                lower: [],
                upper: [pinyinNormalized],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedGreaterThan(String pinyinNormalized, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'pinyinNormalized',
          lower: [pinyinNormalized],
          includeLower: include,
          upper: [],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedLessThan(String pinyinNormalized, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'pinyinNormalized',
          lower: [],
          upper: [pinyinNormalized],
          includeUpper: include,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedBetween(
    String lowerPinyinNormalized,
    String upperPinyinNormalized, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'pinyinNormalized',
          lower: [lowerPinyinNormalized],
          includeLower: includeLower,
          upper: [upperPinyinNormalized],
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedStartsWith(String PinyinNormalizedPrefix) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'pinyinNormalized',
          lower: [PinyinNormalizedPrefix],
          upper: ['$PinyinNormalizedPrefix\u{FFFFF}'],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'pinyinNormalized', value: ['']),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  pinyinNormalizedIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.lessThan(
                indexName: r'pinyinNormalized',
                upper: [''],
              ),
            )
            .addWhereClause(
              IndexWhereClause.greaterThan(
                indexName: r'pinyinNormalized',
                lower: [''],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.greaterThan(
                indexName: r'pinyinNormalized',
                lower: [''],
              ),
            )
            .addWhereClause(
              IndexWhereClause.lessThan(
                indexName: r'pinyinNormalized',
                upper: [''],
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> levelEqualTo(
    int level,
  ) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'level', value: [level]),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  levelNotEqualTo(int level) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'level',
                lower: [],
                upper: [level],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'level',
                lower: [level],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'level',
                lower: [level],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'level',
                lower: [],
                upper: [level],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  levelGreaterThan(int level, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'level',
          lower: [level],
          includeLower: include,
          upper: [],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> levelLessThan(
    int level, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'level',
          lower: [],
          upper: [level],
          includeUpper: include,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause> levelBetween(
    int lowerLevel,
    int upperLevel, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'level',
          lower: [lowerLevel],
          includeLower: includeLower,
          upper: [upperLevel],
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  wordTypeEqualTo(String wordType) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'wordType', value: [wordType]),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  wordTypeNotEqualTo(String wordType) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'wordType',
                lower: [],
                upper: [wordType],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'wordType',
                lower: [wordType],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'wordType',
                lower: [wordType],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'wordType',
                lower: [],
                upper: [wordType],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  nextReviewEqualTo(DateTime nextReview) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'nextReview', value: [nextReview]),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  nextReviewNotEqualTo(DateTime nextReview) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'nextReview',
                lower: [],
                upper: [nextReview],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'nextReview',
                lower: [nextReview],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'nextReview',
                lower: [nextReview],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'nextReview',
                lower: [],
                upper: [nextReview],
                includeUpper: false,
              ),
            );
      }
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  nextReviewGreaterThan(DateTime nextReview, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'nextReview',
          lower: [nextReview],
          includeLower: include,
          upper: [],
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  nextReviewLessThan(DateTime nextReview, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'nextReview',
          lower: [],
          upper: [nextReview],
          includeUpper: include,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  nextReviewBetween(
    DateTime lowerNextReview,
    DateTime upperNextReview, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.between(
          indexName: r'nextReview',
          lower: [lowerNextReview],
          includeLower: includeLower,
          upper: [upperNextReview],
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  needsSyncEqualTo(bool needsSync) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IndexWhereClause.equalTo(indexName: r'needsSync', value: [needsSync]),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterWhereClause>
  needsSyncNotEqualTo(bool needsSync) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'needsSync',
                lower: [],
                upper: [needsSync],
                includeUpper: false,
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'needsSync',
                lower: [needsSync],
                includeLower: false,
                upper: [],
              ),
            );
      } else {
        return query
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'needsSync',
                lower: [needsSync],
                includeLower: false,
                upper: [],
              ),
            )
            .addWhereClause(
              IndexWhereClause.between(
                indexName: r'needsSync',
                lower: [],
                upper: [needsSync],
                includeUpper: false,
              ),
            );
      }
    });
  }
}

extension VocabIsarModelQueryFilter
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QFilterCondition> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'characters',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'characters',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'characters',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'characters',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'characters',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'characters',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'characters',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'characters',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'characters', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersElementIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'characters', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'characters', length, true, length, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'characters', 0, true, 0, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'characters', 0, false, 999999, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersLengthLessThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'characters', 0, true, length, include);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersLengthGreaterThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'characters', length, include, 999999, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  charactersLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'characters',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  easeFactorEqualTo(double value, {double epsilon = Query.epsilon}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'easeFactor',
          value: value,

          epsilon: epsilon,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  easeFactorGreaterThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'easeFactor',
          value: value,

          epsilon: epsilon,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  easeFactorLessThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'easeFactor',
          value: value,

          epsilon: epsilon,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  easeFactorBetween(
    double lower,
    double upper, {
    bool includeLower = true,
    bool includeUpper = true,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'easeFactor',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,

          epsilon: epsilon,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'exampleSentences', length, true, length, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'exampleSentences', 0, true, 0, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'exampleSentences', 0, false, 999999, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesLengthLessThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'exampleSentences', 0, true, length, include);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesLengthGreaterThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'exampleSentences',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'exampleSentences',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'hanzi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'hanzi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'hanzi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'hanzi',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'hanzi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'hanzi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'hanzi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'hanzi',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'hanzi', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  hanziIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'hanzi', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition> idEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'id',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'id',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idLessThan(String value, {bool include = false, bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'id',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition> idBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'id',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'id',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'id',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'id',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition> idMatches(
    String pattern, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'id',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'id', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  idIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'id', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  intervalEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'interval', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  intervalGreaterThan(int value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'interval',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  intervalLessThan(int value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'interval',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  intervalBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'interval',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  isBookmarkedEqualTo(bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'isBookmarked', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  isMasteredEqualTo(bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'isMastered', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  isarIdEqualTo(Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'isarId', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  isarIdGreaterThan(Id value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'isarId',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  isarIdLessThan(Id value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'isarId',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  isarIdBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'isarId',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  levelEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'level', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  levelGreaterThan(int value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'level',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  levelLessThan(int value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'level',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  levelBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'level',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'meaning',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'meaning',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'meaning',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'meaning',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'meaning',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'meaning',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'meaning',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'meaning',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'meaning', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'meaning', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsLengthEqualTo(int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'meanings', length, true, length, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'meanings', 0, true, 0, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'meanings', 0, false, 999999, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsLengthLessThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'meanings', 0, true, length, include);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsLengthGreaterThan(int length, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(r'meanings', length, include, 999999, true);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'meanings',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  needsSyncEqualTo(bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'needsSync', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  nextReviewEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'nextReview', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  nextReviewGreaterThan(DateTime value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'nextReview',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  nextReviewLessThan(DateTime value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'nextReview',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  nextReviewBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'nextReview',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'pinyin',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'pinyin',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'pinyin', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'pinyin', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'pinyinNormalized',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'pinyinNormalized',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'pinyinNormalized',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'pinyinNormalized', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  pinyinNormalizedIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'pinyinNormalized', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  repetitionsEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'repetitions', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  repetitionsGreaterThan(int value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'repetitions',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  repetitionsLessThan(int value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'repetitions',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  repetitionsBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'repetitions',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  updatedAtEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'updatedAt', value: value),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  updatedAtGreaterThan(DateTime value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'updatedAt',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  updatedAtLessThan(DateTime value, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'updatedAt',
          value: value,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  updatedAtBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'updatedAt',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'wordType',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'wordType',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'wordType',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'wordType',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'wordType',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'wordType',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'wordType',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'wordType',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'wordType', value: ''),
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  wordTypeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'wordType', value: ''),
      );
    });
  }
}

extension VocabIsarModelQueryObject
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QFilterCondition> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  exampleSentencesElement(FilterQuery<ExampleSentenceEmbedded> q) {
    return QueryBuilder.apply(this, (query) {
      return query.object(q, r'exampleSentences');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterFilterCondition>
  meaningsElement(FilterQuery<MeaningEmbedded> q) {
    return QueryBuilder.apply(this, (query) {
      return query.object(q, r'meanings');
    });
  }
}

extension VocabIsarModelQueryLinks
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QFilterCondition> {}

extension VocabIsarModelQuerySortBy
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QSortBy> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByEaseFactor() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'easeFactor', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByEaseFactorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'easeFactor', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByHanzi() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hanzi', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByHanziDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hanzi', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByInterval() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'interval', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByIntervalDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'interval', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByIsBookmarked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByIsBookmarkedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByIsMastered() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isMastered', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByIsMasteredDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isMastered', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'level', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByLevelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'level', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByMeaning() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'meaning', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByMeaningDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'meaning', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByNeedsSync() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'needsSync', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByNeedsSyncDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'needsSync', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByNextReview() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nextReview', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByNextReviewDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nextReview', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByPinyin() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByPinyinDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByPinyinNormalized() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByPinyinNormalizedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByRepetitions() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'repetitions', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByRepetitionsDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'repetitions', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> sortByWordType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wordType', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  sortByWordTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wordType', Sort.desc);
    });
  }
}

extension VocabIsarModelQuerySortThenBy
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QSortThenBy> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByEaseFactor() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'easeFactor', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByEaseFactorDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'easeFactor', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByHanzi() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hanzi', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByHanziDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'hanzi', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByInterval() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'interval', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByIntervalDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'interval', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByIsBookmarked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByIsBookmarkedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isBookmarked', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByIsMastered() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isMastered', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByIsMasteredDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isMastered', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByIsarId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isarId', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByIsarIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isarId', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'level', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByLevelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'level', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByMeaning() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'meaning', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByMeaningDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'meaning', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByNeedsSync() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'needsSync', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByNeedsSyncDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'needsSync', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByNextReview() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nextReview', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByNextReviewDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'nextReview', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByPinyin() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByPinyinDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyin', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByPinyinNormalized() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByPinyinNormalizedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'pinyinNormalized', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByRepetitions() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'repetitions', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByRepetitionsDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'repetitions', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy> thenByWordType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wordType', Sort.asc);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QAfterSortBy>
  thenByWordTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'wordType', Sort.desc);
    });
  }
}

extension VocabIsarModelQueryWhereDistinct
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> {
  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByCharacters() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'characters');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByEaseFactor() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'easeFactor');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctByHanzi({
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'hanzi', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctById({
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'id', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctByInterval() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'interval');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByIsBookmarked() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isBookmarked');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByIsMastered() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isMastered');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctByLevel() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'level');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctByMeaning({
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'meaning', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByNeedsSync() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'needsSync');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByNextReview() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'nextReview');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctByPinyin({
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'pinyin', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByPinyinNormalized({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(
        r'pinyinNormalized',
        caseSensitive: caseSensitive,
      );
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByRepetitions() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'repetitions');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct>
  distinctByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'updatedAt');
    });
  }

  QueryBuilder<VocabIsarModel, VocabIsarModel, QDistinct> distinctByWordType({
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'wordType', caseSensitive: caseSensitive);
    });
  }
}

extension VocabIsarModelQueryProperty
    on QueryBuilder<VocabIsarModel, VocabIsarModel, QQueryProperty> {
  QueryBuilder<VocabIsarModel, int, QQueryOperations> isarIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isarId');
    });
  }

  QueryBuilder<VocabIsarModel, List<String>, QQueryOperations>
  charactersProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'characters');
    });
  }

  QueryBuilder<VocabIsarModel, double, QQueryOperations> easeFactorProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'easeFactor');
    });
  }

  QueryBuilder<VocabIsarModel, List<ExampleSentenceEmbedded>, QQueryOperations>
  exampleSentencesProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'exampleSentences');
    });
  }

  QueryBuilder<VocabIsarModel, String, QQueryOperations> hanziProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'hanzi');
    });
  }

  QueryBuilder<VocabIsarModel, String, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<VocabIsarModel, int, QQueryOperations> intervalProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'interval');
    });
  }

  QueryBuilder<VocabIsarModel, bool, QQueryOperations> isBookmarkedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isBookmarked');
    });
  }

  QueryBuilder<VocabIsarModel, bool, QQueryOperations> isMasteredProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isMastered');
    });
  }

  QueryBuilder<VocabIsarModel, int, QQueryOperations> levelProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'level');
    });
  }

  QueryBuilder<VocabIsarModel, String, QQueryOperations> meaningProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'meaning');
    });
  }

  QueryBuilder<VocabIsarModel, List<MeaningEmbedded>, QQueryOperations>
  meaningsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'meanings');
    });
  }

  QueryBuilder<VocabIsarModel, bool, QQueryOperations> needsSyncProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'needsSync');
    });
  }

  QueryBuilder<VocabIsarModel, DateTime, QQueryOperations>
  nextReviewProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'nextReview');
    });
  }

  QueryBuilder<VocabIsarModel, String, QQueryOperations> pinyinProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'pinyin');
    });
  }

  QueryBuilder<VocabIsarModel, String, QQueryOperations>
  pinyinNormalizedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'pinyinNormalized');
    });
  }

  QueryBuilder<VocabIsarModel, int, QQueryOperations> repetitionsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'repetitions');
    });
  }

  QueryBuilder<VocabIsarModel, DateTime, QQueryOperations> updatedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'updatedAt');
    });
  }

  QueryBuilder<VocabIsarModel, String, QQueryOperations> wordTypeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'wordType');
    });
  }
}

// **************************************************************************
// IsarEmbeddedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

const MeaningEmbeddedSchema = Schema(
  name: r'MeaningEmbedded',
  id: 8442337416435577732,
  properties: {
    r'en': PropertySchema(id: 0, name: r'en', type: IsarType.string),
    r'pos': PropertySchema(id: 1, name: r'pos', type: IsarType.string),
    r'vi': PropertySchema(id: 2, name: r'vi', type: IsarType.string),
  },

  estimateSize: _meaningEmbeddedEstimateSize,
  serialize: _meaningEmbeddedSerialize,
  deserialize: _meaningEmbeddedDeserialize,
  deserializeProp: _meaningEmbeddedDeserializeProp,
);

int _meaningEmbeddedEstimateSize(
  MeaningEmbedded object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.en;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  bytesCount += 3 + object.pos.length * 3;
  bytesCount += 3 + object.vi.length * 3;
  return bytesCount;
}

void _meaningEmbeddedSerialize(
  MeaningEmbedded object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeString(offsets[0], object.en);
  writer.writeString(offsets[1], object.pos);
  writer.writeString(offsets[2], object.vi);
}

MeaningEmbedded _meaningEmbeddedDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = MeaningEmbedded();
  object.en = reader.readStringOrNull(offsets[0]);
  object.pos = reader.readString(offsets[1]);
  object.vi = reader.readString(offsets[2]);
  return object;
}

P _meaningEmbeddedDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readStringOrNull(offset)) as P;
    case 1:
      return (reader.readString(offset)) as P;
    case 2:
      return (reader.readString(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

extension MeaningEmbeddedQueryFilter
    on QueryBuilder<MeaningEmbedded, MeaningEmbedded, QFilterCondition> {
  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNull(property: r'en'),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        const FilterCondition.isNotNull(property: r'en'),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enEqualTo(String? value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'en',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'en',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enLessThan(String? value, {bool include = false, bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'en',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'en',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'en',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'en',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'en',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'en',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'en', value: ''),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  enIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'en', value: ''),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'pos',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'pos',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posLessThan(String value, {bool include = false, bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'pos',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'pos',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'pos',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'pos',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'pos',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'pos',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'pos', value: ''),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  posIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'pos', value: ''),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viLessThan(String value, {bool include = false, bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'vi',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'vi',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'vi', value: ''),
      );
    });
  }

  QueryBuilder<MeaningEmbedded, MeaningEmbedded, QAfterFilterCondition>
  viIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'vi', value: ''),
      );
    });
  }
}

extension MeaningEmbeddedQueryObject
    on QueryBuilder<MeaningEmbedded, MeaningEmbedded, QFilterCondition> {}

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

const ExampleSentenceEmbeddedSchema = Schema(
  name: r'ExampleSentenceEmbedded',
  id: -4283432897740262040,
  properties: {
    r'cn': PropertySchema(id: 0, name: r'cn', type: IsarType.string),
    r'pinyin': PropertySchema(id: 1, name: r'pinyin', type: IsarType.string),
    r'vi': PropertySchema(id: 2, name: r'vi', type: IsarType.string),
  },

  estimateSize: _exampleSentenceEmbeddedEstimateSize,
  serialize: _exampleSentenceEmbeddedSerialize,
  deserialize: _exampleSentenceEmbeddedDeserialize,
  deserializeProp: _exampleSentenceEmbeddedDeserializeProp,
);

int _exampleSentenceEmbeddedEstimateSize(
  ExampleSentenceEmbedded object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.cn.length * 3;
  bytesCount += 3 + object.pinyin.length * 3;
  bytesCount += 3 + object.vi.length * 3;
  return bytesCount;
}

void _exampleSentenceEmbeddedSerialize(
  ExampleSentenceEmbedded object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeString(offsets[0], object.cn);
  writer.writeString(offsets[1], object.pinyin);
  writer.writeString(offsets[2], object.vi);
}

ExampleSentenceEmbedded _exampleSentenceEmbeddedDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = ExampleSentenceEmbedded();
  object.cn = reader.readString(offsets[0]);
  object.pinyin = reader.readString(offsets[1]);
  object.vi = reader.readString(offsets[2]);
  return object;
}

P _exampleSentenceEmbeddedDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readString(offset)) as P;
    case 1:
      return (reader.readString(offset)) as P;
    case 2:
      return (reader.readString(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

extension ExampleSentenceEmbeddedQueryFilter
    on
        QueryBuilder<
          ExampleSentenceEmbedded,
          ExampleSentenceEmbedded,
          QFilterCondition
        > {
  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'cn',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'cn',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnLessThan(String value, {bool include = false, bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'cn',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'cn',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'cn',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'cn',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'cn',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'cn',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'cn', value: ''),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  cnIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'cn', value: ''),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'pinyin',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'pinyin',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'pinyin',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'pinyin', value: ''),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  pinyinIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'pinyin', value: ''),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viEqualTo(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(
          include: include,
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viLessThan(String value, {bool include = false, bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.lessThan(
          include: include,
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.between(
          property: r'vi',
          lower: lower,
          includeLower: includeLower,
          upper: upper,
          includeUpper: includeUpper,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viStartsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.startsWith(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viEndsWith(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.endsWith(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.contains(
          property: r'vi',
          value: value,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.matches(
          property: r'vi',
          wildcard: pattern,
          caseSensitive: caseSensitive,
        ),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.equalTo(property: r'vi', value: ''),
      );
    });
  }

  QueryBuilder<
    ExampleSentenceEmbedded,
    ExampleSentenceEmbedded,
    QAfterFilterCondition
  >
  viIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(
        FilterCondition.greaterThan(property: r'vi', value: ''),
      );
    });
  }
}

extension ExampleSentenceEmbeddedQueryObject
    on
        QueryBuilder<
          ExampleSentenceEmbedded,
          ExampleSentenceEmbedded,
          QFilterCondition
        > {}
