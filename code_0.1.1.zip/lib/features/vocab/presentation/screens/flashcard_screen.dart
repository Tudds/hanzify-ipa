import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hanzify/core/theme/colors.dart';
import 'package:hanzify/features/vocab/domain/entities/vocab.dart';
import 'package:hanzify/features/vocab/presentation/providers/vocab_state.dart';
import 'package:hanzify/core/theme/theme_state.dart';
import 'package:hanzify/core/providers/navigation_provider.dart';

class FlashcardScreen extends ConsumerStatefulWidget {
  const FlashcardScreen({super.key});

  @override
  ConsumerState<FlashcardScreen> createState() => _FlashcardScreenState();
}

class _FlashcardScreenState extends ConsumerState<FlashcardScreen>
    with TickerProviderStateMixin {
  int _currentIndex = 0;
  bool _isFlipped = false;
  int _reviewedCount = 0;
  bool _isFinished = false;
  bool? _scoreFeedback; 

  late PageController _pageController;
  late AnimationController _flipCtrl;
  late Animation<double> _flipAnim;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.85);
    _flipCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _flipAnim = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _flipCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _pageController.dispose();
    _flipCtrl.dispose();
    super.dispose();
  }

  void _flipCard() {
    if (_isFlipped) {
      _flipCtrl.reverse();
    } else {
      _flipCtrl.forward();
    }
    setState(() => _isFlipped = !_isFlipped);
  }

  Future<void> _handleScore(List<Vocab> cards, int score, AppThemeColors c) async {
    final vocab = cards[_currentIndex];
    
    await ref.read(dueVocabProvider.notifier).review(vocab, score);

    setState(() {
      _reviewedCount++;
      _scoreFeedback = score >= 4;
    });

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) setState(() => _scoreFeedback = null);
    });

    if (_currentIndex + 1 >= cards.length) {
      await Future.delayed(const Duration(milliseconds: 400));
      if (mounted) setState(() => _isFinished = true);
      return;
    }

    if (_pageController.hasClients) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = ref.watch(themeColorsProvider);
    final screenW = MediaQuery.of(context).size.width;
    final cardW = screenW - 48;

    final dueVocabAsync = ref.watch(dueVocabProvider);

    return dueVocabAsync.when(
      data: (cards) {
        if (cards.isEmpty && _reviewedCount == 0) return _buildEmptyState(c);
        if (_isFinished) return _buildFinished(c);
        return _buildMain(cards, c, cardW);
      },
      loading: () => Scaffold(
        backgroundColor: c.background,
        body: const Center(child: CircularProgressIndicator()),
      ),
      error: (err, stack) => Scaffold(
        backgroundColor: c.background,
        body: Center(child: Text('Lỗi: $err', style: TextStyle(color: c.error))),
      ),
    );
  }

  Widget _buildEmptyState(AppThemeColors c) {
    return Scaffold(
      backgroundColor: c.background,
      body: Column(children: [
        _buildHeader(c, 0, 0),
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        c.accent.withValues(alpha: 0.15),
                        c.primary.withValues(alpha: 0.08),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: const Center(child: Text('🎉', style: TextStyle(fontSize: 48))),
                ),
                const SizedBox(height: 24),
                Text('Không có từ nào cần ôn!',
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: c.text)),
                const SizedBox(height: 8),
                Text(
                  'Hãy quay lại sau hoặc thêm từ vựng mới.',
                  style: TextStyle(
                      fontSize: 15, color: c.placeholder, height: 1.5),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                ElevatedButton(
                  onPressed: () => ref.read(navigationProvider.notifier).navigate('home'),
                  child: const Text('Về Trang Chủ'),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildFinished(AppThemeColors c) {
    return Scaffold(
      backgroundColor: c.background,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    c.primary.withValues(alpha: 0.2),
                    c.accent.withValues(alpha: 0.1),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Center(
                  child: Text('🏆', style: TextStyle(fontSize: 56))),
            ),
            const SizedBox(height: 24),
            Text('Hoàn thành!',
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: c.text)),
            const SizedBox(height: 8),
            Text('Bạn đã ôn tập $_reviewedCount từ vựng',
                style: TextStyle(fontSize: 16, color: c.placeholder)),
            const SizedBox(height: 32),
            GestureDetector(
              onTap: () => ref.read(navigationProvider.notifier).navigate('home'),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 16, horizontal: 40),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [c.primary, c.accent],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                        color: c.primary.withValues(alpha: 0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4)),
                  ],
                ),
                child: const Text('Về Trang Chủ',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildMain(List<Vocab> cards, AppThemeColors c, double cardW) {
    final progress = (_currentIndex + 1) / cards.length;

    return Scaffold(
      backgroundColor: c.background,
      body: Column(
        children: [
          _buildHeader(c, _currentIndex, cards.length),
          Container(
            height: 5,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
                color: c.disabled.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(3)),
            child: Align(
              alignment: Alignment.centerLeft,
              child: AnimatedFractionallySizedBox(
                duration: const Duration(milliseconds: 300),
                widthFactor: progress,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [c.primary, c.accent],
                    ),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              physics: _isFlipped 
                  ? const NeverScrollableScrollPhysics() 
                  : const BouncingScrollPhysics(),
              onPageChanged: (index) {
                setState(() {
                  _currentIndex = index;
                  _isFlipped = false;
                });
                _flipCtrl.value = 0;
              },
              itemCount: cards.length,
              itemBuilder: (context, index) {
                return AnimatedBuilder(
                  animation: _pageController,
                  builder: (context, child) {
                    double value = 1.0;
                    if (_pageController.position.haveDimensions) {
                      value = _pageController.page! - index;
                      value = (1 - (value.abs() * 0.3)).clamp(0.0, 1.0);
                    }

                    return Center(
                      child: Transform.scale(
                        scale: Curves.easeOut.transform(value),
                        child: Opacity(
                          opacity: value,
                          child: _buildDismissibleCard(cards[index], c, cardW, index, cards),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 32),
            child: _isFlipped 
              ? _buildMiddleScoreButtons(cards, c)
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.touch_app_rounded,
                        size: 18, color: c.disabled),
                    const SizedBox(width: 6),
                    Text('Chạm thẻ để xem đáp án',
                        style: TextStyle(fontSize: 15, color: c.placeholder)),
                  ],
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildDismissibleCard(Vocab vocab, AppThemeColors c, double cardW, int index, List<Vocab> allCards) {
    if (!_isFlipped) {
      return GestureDetector(
        onTap: _flipCard,
        child: Hero(
          tag: index == 0 ? 'flashcard_hero' : 'flashcard_hero_${vocab.id}',
          child: Material(
            color: Colors.transparent,
            child: _buildFront(vocab, c, cardW),
          ),
        ),
      );
    }

    return Stack(
      children: [
        Dismissible(
          key: Key('card_${vocab.id}_$_currentIndex'),
          direction: DismissDirection.horizontal,
          confirmDismiss: (direction) async {
            if (direction == DismissDirection.startToEnd) {
              await _handleScore(allCards, 5, c);
            } else {
              await _handleScore(allCards, 0, c);
            }
            return false;
          },
          background: _buildDismissBackground(true, c),
          secondaryBackground: _buildDismissBackground(false, c),
          child: GestureDetector(
            onTap: _flipCard,
            child: AnimatedBuilder(
              animation: _flipAnim,
              builder: (_, child) => Transform(
                alignment: Alignment.center,
                transform: Matrix4.identity()
                  ..setEntry(3, 2, 0.001)
                  ..rotateY(_flipAnim.value * pi),
                child: _flipAnim.value < 0.5
                    ? _buildFront(vocab, c, cardW)
                    : Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()..rotateY(pi),
                        child: _buildBack(vocab, c, cardW),
                      ),
              ),
            ),
          ),
        ),
        _buildScoreFeedbackOverlay(c),
      ],
    );
  }

  Widget _buildScoreFeedbackOverlay(AppThemeColors c) {
    if (_scoreFeedback == null) return const SizedBox.shrink();
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: _scoreFeedback! 
                ? c.success.withValues(alpha: 0.15)
                : c.danger.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(28),
          ),
          child: Center(
            child: Icon(
              _scoreFeedback! ? Icons.check_circle_rounded : Icons.replay_rounded,
              size: 80,
              color: (_scoreFeedback! ? c.success : c.danger).withValues(alpha: 0.5),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDismissBackground(bool isStart, AppThemeColors c) {
    final color = isStart ? c.success : c.danger;
    return Container(
      alignment: isStart ? Alignment.centerLeft : Alignment.centerRight,
      padding: const EdgeInsets.symmetric(horizontal: 40),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isStart 
            ? [color.withValues(alpha: 0.8), Colors.transparent]
            : [Colors.transparent, color.withValues(alpha: 0.8)],
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(isStart ? '🤩' : '😵', style: const TextStyle(fontSize: 48)),
          const SizedBox(height: 8),
          Text(isStart ? 'Dễ' : 'Quên', 
            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildMiddleScoreButtons(List<Vocab> cards, AppThemeColors c) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildSimpleScoreButton(cards, 3, 'Khó', '😰', c.warning, c),
        const SizedBox(width: 20),
        _buildSimpleScoreButton(cards, 4, 'Tốt', '😊', const Color(0xFF3B82F6), c),
      ],
    );
  }

  Widget _buildSimpleScoreButton(List<Vocab> cards, int score, String label, String emoji, Color color, AppThemeColors c) {
    return GestureDetector(
      onTap: () => _handleScore(cards, score, c),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 3)),
          ],
        ),
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(AppThemeColors c, int current, int total) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () => ref.read(navigationProvider.notifier).navigate('home'),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: c.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text('← Về',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: c.primary)),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: c.surfaceLow,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text('${total > 0 ? current + 1 : 0} / $total',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: c.text)),
          ),
        ],
      ),
    );
  }

  Widget _buildFront(Vocab vocab, AppThemeColors c, double cardW) {
    return Container(
      width: cardW,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c.surface, c.surfaceLow],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(28),
        border:
            Border.all(color: c.disabled.withValues(alpha: 0.15), width: 1),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 8)),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 20,
            right: 20,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    c.accent.withValues(alpha: 0.2),
                    c.accent.withValues(alpha: 0.08),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text('HSK ${vocab.level}',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: _getLevelColor(vocab.level))),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(vocab.hanzi,
                    style: TextStyle(
                        fontSize: 80,
                        fontWeight: FontWeight.w800,
                        color: c.text,
                        height: 1.1)),
                const SizedBox(height: 12),
                Container(
                  width: 40,
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [c.primary, c.accent]),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 24,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.flip_rounded, size: 16, color: c.disabled),
                const SizedBox(width: 6),
                Text('Chạm để lật thẻ',
                    style: TextStyle(fontSize: 13, color: c.disabled)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBack(Vocab vocab, AppThemeColors c, double cardW) {
    return Container(
      width: cardW,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c.surfaceLow, c.surface],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(28),
        border:
            Border.all(color: c.primary.withValues(alpha: 0.15), width: 1),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 8)),
        ],
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(vocab.hanzi,
            style: TextStyle(
                fontSize: 44, fontWeight: FontWeight.w700, color: c.text)),
        const SizedBox(height: 6),
        Text(vocab.pinyin,
            style: TextStyle(
                fontSize: 22, fontWeight: FontWeight.w500, color: c.primary)),
        const SizedBox(height: 16),
        Container(
          height: 1,
          width: 80,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                c.disabled.withValues(alpha: 0.0),
                c.disabled.withValues(alpha: 0.4),
                c.disabled.withValues(alpha: 0.0),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(vocab.meaning,
            style: TextStyle(
                fontSize: 24, fontWeight: FontWeight.w600, color: c.text),
            textAlign: TextAlign.center),
        if (vocab.exampleSentences.isNotEmpty) ...[
          const SizedBox(height: 20),
          ...vocab.exampleSentences.take(2).map((s) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text('• $s',
                    style: TextStyle(
                        fontSize: 14, color: c.placeholder, height: 1.5),
                    textAlign: TextAlign.center),
              )),
        ],
      ]),
    );
  }

  Color _getLevelColor(int level) {
    const colors = {
      1: Color(0xFF10B981),
      2: Color(0xFF3B82F6),
      3: Color(0xFFF59E0B),
      4: Color(0xFFEF4444),
      5: Color(0xFF8B5CF6),
      6: Color(0xFFEC4899),
    };
    return colors[level] ?? const Color(0xFF6B7280);
  }
}



